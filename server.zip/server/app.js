require("dotenv").config();
const express = require("express");
const app = express();
const mongoose = require("mongoose");
require("./db/conn")
 

const port=  8005;
// app.get('/hello',(req,res)=>{
//     res.end("hello world");
// })

app.listen(port, ()=>{
    console.log("server is running on port number 8005");
});

//user schema
const userSchema = new mongoose.Schema({
    name: String,
    age: Number,
})

const UserModel = mongoose.model("users",userSchema)

app.get("/getuser", async (req, res) => {
    const userData = await UserModel.find();
    res.json(userData);
})